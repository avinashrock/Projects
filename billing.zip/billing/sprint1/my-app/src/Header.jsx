import React from 'react';
import './Header.css';

class Header extends React.Component {
    render() {
        return (

            <tr class="table table-hover">
                <th className="first-col-height">Item</th>
                <th className="col-height">Rate</th>
                <th className="col-height">Qty</th>
                <th className="col-height">GST</th>
                <th className="col-height"><b>Amount</b></th>
            </tr>
        );
    }
}
export default Header;
