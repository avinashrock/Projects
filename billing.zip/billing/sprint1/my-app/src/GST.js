export function Biller(bill, amount, quantity, tax) {
    function roundToTwo(num) {
       	return +(`${Math.round(`${num}e+2`)}e-2`);
    }
    bill.gross += (amount * quantity);
    bill.gst += (((parseFloat(tax) * amount) / 100) * quantity);
    bill.serviceCharge = (0.1 * bill.gross);
    bill.grandTotal = bill.gross + bill.gst + bill.serviceCharge;
    bill.gross = roundToTwo(bill.gross);
    bill.gst = roundToTwo(bill.gst);
    bill.serviceCharge = roundToTwo(bill.serviceCharge);
    bill.grandTotal = roundToTwo(bill.grandTotal);
    return bill;
}

