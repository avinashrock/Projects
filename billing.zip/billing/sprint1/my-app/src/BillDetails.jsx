import React from 'react';
import BillBreakup from './BillBreakup';
import { Biller } from './GST';

class BillDetails extends React.Component {
    constructor(props) {
        super(props);
        this.getTotalBill = this.getTotalBill.bind(this);
        this.printTotalBill = this.printTotalBill.bind(this);
    }
    getTotalBill() {
        const totalBill = {
            gross: 0,
            gst: 0,
            serviceCharge: 0,
            grandTotal: 0,
        };
       const dataState = this.props.modify;
       dataState.forEach((parameter) => {
            Biller(totalBill, parameter.rate, parameter.qty, parameter.gst);
        });
        return totalBill;
    }
    printTotalBill() {
        window.print();
    }
    render() {
        return (
            <React.Fragment>
                <div>
                    <BillBreakup bill={this.getTotalBill()} />
                </div>
                <button type="button" className="btn btn-primary" onClick={this.printTotalBill}>print</button>

            </React.Fragment>
        );
    }
}
export default BillDetails;
