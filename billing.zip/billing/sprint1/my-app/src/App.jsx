import React from 'react';
import {HashRouter} from 'react-router-dom';
import Billing from './Billing';
import {Route} from 'react-router-dom';
class App extends React.Component{
    render(){
    return(
    <HashRouter>
    
    <Route  path='/:number?' component={Billing}/>
    
    </HashRouter>
    );

    }
}
export default (<App />);
