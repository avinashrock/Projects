import React from 'react';
import './BillBreakup.css';

class BillBreakup extends React.Component {
    render() {
        const {
            bill: {
                gross, gst, serviceCharge, grandTotal,
            },
        } = this.props;
        return (
            <div className="totalBreakup">
                <div className="Row">
                    <div className="Bill">
                Gross :
                    </div>
                    <div className="Bill">
                 &#x20b9;{gross} /-
                    </div>
                </div>

                <div className="Row">
                    <div className="Bill">
                GST :
                    </div>
                    <div className="Bill">
                &#x20b9; {gst} /-
                    </div>

                </div>

                <div className="Row">
                    <div className="Bill">
                Service Charges(10%) :
                    </div>
                    <div className="Bill">
                &#x20b9; {serviceCharge} /-
                    </div>
                </div>

                <div className="Row">
                    <div className="Bill">
                        <h2>Grand Total : </h2>
                    </div>
                    <div className="Bill">
                        <h2>  &#x20b9; {grandTotal} /-</h2>
                    </div>
                </div>
            </div>
        );
    }
}

export default BillBreakup;
