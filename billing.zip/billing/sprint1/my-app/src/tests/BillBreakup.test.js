import React from 'react';
import {shallow,mount,render} from 'enzyme';
import BillBreakup from '../BillBreakup';

describe('BillBreakup component rendering',()=>{
	const props = {bill: {
						gross:50,
						gst:'5%',
						serviceCharge:10,
						grandTotal:330,
		},
	};
	const wrapper = shallow(<BillBreakup {...props} />);
	it('main div rendering correctly',()=>{
		expect(wrapper.find('div').at(0).hasClass('totalBreakup'));
	})

	it('all the divs are rendering',() =>{
		expect(wrapper.find('div')).toHaveLength(13);
	})

	it('gross rendering correctly',()=>{
		expect(wrapper.find('div').at(3).text()).toEqual('₹50 /-');
	})

	it('gst rendering correctly',()=>{
		expect(wrapper.find('div').at(6).text()).toEqual('₹ 5% /-');
	})

	it('serviceCharge rendering correctly',()=>{
		expect(wrapper.find('div').at(9).text()).toEqual('₹ 10 /-');
	})

	it('grandTotal rendering correctly',()=>{
		expect(wrapper.find('div').at(12).text()).toEqual('  ₹ 330 /-');
	})
})