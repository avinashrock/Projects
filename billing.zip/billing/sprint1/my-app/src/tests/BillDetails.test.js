import React from 'react';
import {shallow,render,mount} from 'enzyme';
import BillDetails from '../BillDetails';

describe('BillDetails rendering correctly', ()=>{
	const props = {
		modify: [{
			item:'',
			rate:0,
			qty:0,
			gst:0,
		}],
	};
	const wrapper = shallow(<BillDetails {...props} />)
	it('div is rendering properly',()=>{
		expect(wrapper.find('div')).toHaveLength(1);
	})

	it('button componentn renders properly',()=>{
		expect(wrapper.find('button').hasClass('btn btn-primary')).toEqual(true);

		})

	it('button simulates on click',()=>{
		expect(wrapper.find('button').simulate('click'));
	})

	describe('BillBreakup component renders as child',()=>{
		const component = mount(<BillDetails {...props} />);
		it('succesfully rendered',()=>{
			expect(component.find('BillBreakup')).toBeDefined();
		})
	})



})