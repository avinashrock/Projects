import React from 'react';
import { shallow, mount, render } from 'enzyme';
import TableRow from '../TableRow';

describe('TableRow is rendering correctly',()=>{
	const dataset = {
		data:{item:'x',rate:5,qty:0,gst:'5%'},
	};
	
	const wrapper = shallow(<TableRow {...dataset} />);

	it('table is rendering fine',()=>{
		expect(wrapper.find('tr').length).toBe(1);
	})

	it('table has className as item',() =>{
		expect(wrapper.find('tr').hasClass('item')).toEqual(true);
	})

	it('renders typeahead properly',() =>{
		const typeahead = mount(<TableRow {...dataset}/>);
		expect(typeahead.find('Typeahead')).toHaveLength(2);
	})

	it('renders input element properly',()=>{
		expect(wrapper.find('input').length).toBe(1);
	})

	

	it('renders rate properly',()=>{
		expect(wrapper.find('td').at(1).text()).toEqual('5');
	})

	it('renders qty properly',()=>{
		expect(wrapper.find('td').at(2).text()).toEqual(' ');
	})

	it('renders gst properly',()=>{
		expect(wrapper.find('td').at(3).text()).toEqual('5%');
	})

	it('renders amount correctly',()=>{
		expect(wrapper.find('td').at(4).text()).toEqual('0');
	})

})