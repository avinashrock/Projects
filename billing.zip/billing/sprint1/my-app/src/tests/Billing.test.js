import React from 'react';
import { shallow, mount, render } from 'enzyme';
import Billing from '../Billing';
import BillDetails from '../BillDetails';
import Header from '../Header';

describe('Billing component', () => {
	const props = {match:{
			params:'1'
		}};
	const wrapper = shallow(<Billing {...props} />);
	it('should have two divs ', () => {
		
		const divComponent = wrapper.find('div');
		expect(divComponent).toHaveLength(2);
	})
	it('should render button correctly', () => {
		
		expect(wrapper.find('button').at(0).hasClass('btn btn-info')).toEqual(true);
	})

	it('button should simulate on click',()=>{
		expect(wrapper.find('button').at(0).simulate('click'));
		
	})

	it('button should simulate on click',()=>{
		
		expect(wrapper.find('button').at(1).simulate('click'));
	})

	it('button should simulate on click',()=>{
		
		expect(wrapper.find('button').at(2).simulate('click'));
	})

	describe('BillDetails rendered correctly',() => {

	it('ok',()=> {
		const wrapper = mount(<Billing {...props}/>);
		expect(wrapper.find('BillDetails')).toHaveLength(1);
	})

	})

	describe('Header rendered correctly',() => {

	it('ok',()=> {
		const wrapper = mount(<Billing {...props}/>);
		expect(wrapper.find('Header')).toHaveLength(1);
	})

	})

	


})