import React from 'react';
import Header from './Header';
import TableRow from './TableRow';
import BillDetails from './BillDetails';

class Billing extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            data: [{
                item: '',
                rate: 0.0,
                qty: 1,
                gst: 0.0,
            }],
            
        };
        this.addItem = this.addItem.bind(this);
        this.updateItem = this.updateItem.bind(this);
        this.saveBill = this.saveBill.bind(this);
        this.updateMode = this.updateMode.bind(this);
        this.reset = this.reset.bind(this);
        this.goBack = this.goBack.bind(this);
        this.getData = this.getData.bind(this);

    }
    getBillId(){return this.props.match.params.number;
    }
    getItems() {
        const data =  this.isReadMode() ? JSON.parse(localStorage.getItem(this.getBillId())) : this.state.data;
        return data.map((dataElements, index) => (<TableRow
            key={index}
            id={index}
            data={dataElements}
            updateItem={this.updateItem}
            readMode={this.isReadMode()}
        />));
    }

    isReadMode(){
     return this.getBillId() !== undefined;
    }


    updateMode() {
        const key = prompt('enter the billid');
        const keyId = parseInt(key);
        if (keyId in localStorage) {
            this.props.history.push(`/${keyId}`);
            alert(`this is your bill statement #${keyId}`);
        } else {
            alert('invalid bill id');
        }
        
    }

    goBack() {
        this.props.history.push('/');
    }

    getData(){
        const data = this.isReadMode() ? JSON.parse(localStorage.getItem(this.getBillId())) : this.state.data;
        return data;
    }

    addItem() {
        const newItem = [{
            item: '',
            rate: 0.0,
            qty: 1,
            gst: 0.0,
        }];
        this.setState({
            data: (this.state.data).concat(newItem),
        });
    }

    updateItem(index, newValue) {
        const newData = this.state.data;
        newData[index] = Object.assign({}, newData[index], newValue);
        const newState = {
            data: newData,
        };
        this.setState(newState);
        if (index === this.state.data.length - 1) {
        	this.addItem();
        	}
    }

    saveBill() {
        const key = localStorage.length;                              
        const dataState = this.state.data;
        localStorage.setItem(key, JSON.stringify(dataState));
        alert("This is your billid" + key);
    
    }

    reset() {
        let newData = this.state.data;
        newData = [{
            item: '',
            rate: 0.0,
            qty: 1,
            gst: 0.0,
        }];
        this.setState({ data: newData });
    }


    render() {
        return (
            <React.Fragment>
                <div>
                    <h1>Bill Generator</h1>
                    <table>
                        <thead>
                            <Header />
                        </thead>
                        <tbody>
                            {this.getItems()}

                        </tbody>
                    </table>
                </div>
                <div>
                    <BillDetails  modify={this.getData()} />
                </div>
                <button type="button" className="btn btn-info" onClick={this.saveBill}>Save</button>
                {" "}
                {(this.isReadMode()) ? <button type="button" className="btn btn-info" onClick={this.goBack}>Back</button> :
                    <button type="button" className="btn btn-info" onClick={this.updateMode}>View</button>}
                {' '}
                <button type="button" className="btn btn-info" onClick={this.reset}>reset</button>
            </React.Fragment>
        );
    }
}
export default Billing;