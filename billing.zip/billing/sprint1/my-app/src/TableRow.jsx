import { Typeahead } from 'react-bootstrap-typeahead';
import 'react-bootstrap-typeahead/css/Typeahead.css';
import React from 'react';
import './TableRow.css';

class TableRow extends React.Component {
    render() {
        const {
            data: {
                item, rate, qty, gst,
            }, updateItem, id, readMode,
        } = this.props;
        const amount = rate * qty * parseFloat(gst) * 0.01;
        const totalAmount = rate * qty + amount;
        function quantityChange({
            target: {
                name, value,
            },
        }) {
            const newItem = {
                item, rate, qty, gst,
            };
            if (name === 'qty') {
                newItem.qty = value;
            }
            updateItem(id, newItem);
        }
        const data = [{
            item: 'Garlic Bread',
            rate: 12,
            gst: '5%',
        }, {
            item: 'Water Bottle',
            rate: 15,
            gst: '5%',
        }, {
            item: 'Pizza',
            rate: 350,
            gst: '5%',
        }];
        const onSelectItem = (selectedValue) => {
            updateItem(id, selectedValue[0]);
        };
        const selectedItem = item === '' ? [] : [{
            item, rate, gst,
        }];
        return (
            <React.Fragment>
                <tr className="item">
                    <td>{!readMode ? <Typeahead
                        placeholder="Items"
                        options={data}
                        labelKey="item"
                        onChange={onSelectItem}
                        selected={selectedItem}
                    /> : item}
                    </td>
                    <td>{rate}</td>
                    <td>{!readMode ? <input name="qty" type="number" value={qty} onChange={quantityChange} /> : qty} </td>
                    <td>{gst}</td>
                    <td><span>{totalAmount}</span></td>
                </tr>
            </React.Fragment>
        );
    }
}
export default TableRow;
